# -*- coding = utf-8 -*-
# @time:2024/9/15 17:51
# Author:zhuzhui
# @File:__init__.py
# @Software:PyCharm


if __name__ == '__main__':
    print("python")
